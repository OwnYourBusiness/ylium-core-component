const readline = require('readline');

const cu = require('./client_utils.js');
const ot = require('./libs/oybns_types.js');

async function cli_handle_account_detail(options)
{
	account = await cu.cli_get_account(options);
	console.log(JSON.stringify(account, null, 4));
	process.exit(0)	
}

async function cli_handle_account_list()
{
	accounts = await ot.search(ot.Account);

	console.log('%-8s %-42s %-42s %s'.F('slot id', 'user address', 'mdi user address', 'MDI server URL'))
	console.log('%-8s %-42s %-42s %s'.F('--', '--', '--', '--'))
	accounts.map(account => {
		console.log('%-8s %-42s %-42s %s'.F(account.id, account.address, account.mdi_user_address, account.mdi_url))
	});

	process.exit(0)	
}

async function cli_handle_account_delete(options, delete_options)
{
	account = await cu.cli_get_account(options);

	console.log("Deleting account at slot id: " + account.id + "\n" + JSON.stringify(account, null, 4));

	const rl = readline.createInterface({
	  input: process.stdin,
	  output: process.stdout
	});

	var response = '***'
	rl.question('Are you sure you want to delete this account?\nType "YES" to continue: ', function (_res) {
		response = _res;
	});
	
	while (response == '***') {await new Promise(resolve => setTimeout(resolve, 1000));}

	if (response == "YES")
	{
		await ot.del(ot.Account, account.id);
		console.log("Account deleted.");

		if (delete_options.x)
		{
			try
			{
				await ot.del(ot.MdiCredentials, [account.mdi_url, account.chain_id, account.mdi_user_address]);
				console.log("Mdi credetials deleted.");
			}
			catch (err)
			{
				if (err.code != 'LEVEL_NOT_FOUND')
					throw(err);

				console.log("Mdi credetials not found.");
			}
		}

		process.exit(0)	
	}

	console.log("Account not deleted.");
	process.exit(1)	
}

async function cli_handle_config_list(options)
{
	config = await ot.search(ot.Config);

	config.map(data => {
		console.log('%s\n\n'.F(JSON.stringify(data, null, 4)))
	});

	process.exit(0)	
}

async function cli_handle_config_create(id, web3_provider_url, chain_id, contract_address, token_address, options)
{
	chain_id = parseInt(chain_id);

	if (chain_id < 0)
	{
		console.log("Error: account chain id should a positive number.")
		process.exit(1)
	}

	let config

	try
	{
		config = await ot.get_nl(ot.Config, [id]);
	}
	catch (err)
	{
		if (err.code != 'LEVEL_NOT_FOUND')
			throw(err);
	}

	if (config)
	{
		console.log('Contract config already exists, please delete and recreate again.');
		process.exit(1)
	}

	config = new ot.Config(id, web3_provider_url, chain_id, contract_address, token_address);
	await ot.put(ot.Config, config);
	console.log('Contract config stored as [' + config.id + '].');

	process.exit(0)
}


async function cli_handle_config_remove(id, options)
{
	config = await await ot.get_nl(ot.Config, [id]);

	console.log("Deleting contract config:\n" + JSON.stringify(config, null, 4));

	const rl = readline.createInterface({
	  input: process.stdin,
	  output: process.stdout
	});

	var response = '***'
	rl.question('Are you sure you want to delete this mdi credentials?\nType "YES" to continue: ', function (_res) {
		response = _res;
	});

	while (response == '***') {await new Promise(resolve => setTimeout(resolve, 1000));}

	if (response == "YES")
	{
		await ot.del(ot.Config, config.id);
		console.log("Contract config deleted.");
		process.exit(0)
	}

	console.log("Contract config not deleted.");
	process.exit(1)
}


async function cli_handle_mdi_credentials_list()
{
	credentials = await ot.search(ot.MdiCredentials);

	credentials.map(credential => {
		console.log('%s\n\n'.F(JSON.stringify(credential, null, 4)))
	});

	process.exit(0)
}

async function cli_handle_mdi_create(mdi_url, chain_id, mdi_user_address, mdi_password, mdi_password_version, options)
{
	chain_id = parseInt(chain_id);

	if (chain_id < 0)
	{
		console.log("Error: account chain id should a positive number.")
		process.exit(1)
	}

	let credential

	try
	{
		credential = await ot.get_nl(ot.MdiCredentials, [mdi_url, chain_id, mdi_user_address]);
	}
	catch (err)
	{
		if (err.code != 'LEVEL_NOT_FOUND')
			throw(err);
	}

	if (credential)
	{
		console.log('Mdi credentials already exists, please delete and recreate again.');
		process.exit(1)
	}

	credential = new ot.MdiCredentials(mdi_url,chain_id, mdi_user_address, mdi_password_version, mdi_password);
	await ot.put(ot.MdiCredentials, credential);
	console.log('Mdi credentials stored/updated as [' + credential.id + '].');

	process.exit(0)
}

async function cli_handle_mdi_remove(mdi_url, chain_id, mdi_user_address, options)
{
	credential = await await ot.get_nl(ot.MdiCredentials, [mdi_url, chain_id, mdi_user_address]);

	console.log("Deleting mdi credential\n" + JSON.stringify(credential, null, 4));

	const rl = readline.createInterface({
	  input: process.stdin,
	  output: process.stdout
	});

	var response = '***'
	rl.question('Are you sure you want to delete this mdi credentials?\nType "YES" to continue: ', function (_res) {
		response = _res;
	});

	while (response == '***') {await new Promise(resolve => setTimeout(resolve, 1000));}

	if (response == "YES")
	{
		await ot.del(ot.MdiCredentials, credential.id);
		console.log("Credential deleted.");
		process.exit(0)
	}

	console.log("Credential not deleted.");
	process.exit(1)
}

async function cli_handle_account_create(mdi_url, mdi_user_address, address, options)
{
	account_slot_id = parseInt(options.account)

	console.log("Creating new account with slot id " + account_slot_id);

	if (! account_slot_id && account_slot_id < 0)
	{
		console.log("Error: account slot id " + account_slot_id + " is not a valid slot.")
		process.exit(1)
	}

	if (account_slot_id >= 100)
	{
		console.log("Error: account slot id should be any number from 0 to 99.")
		process.exit(1)
	}

	var account;

	try
	{
		account = await ot.get_nl(ot.Account, [account_slot_id]);
	}
	catch (err)
	{
		if (err.code != 'LEVEL_NOT_FOUND')
			throw(err);
	}

	if (account)
	{
		console.log("Error: account with slot id " + account_slot_id + " already exists.")
		process.exit(1)
	}

	const readline = require('readline');
	const rl = readline.createInterface({
	  input: process.stdin,
	  output: process.stdout
	});

	var pkey = '0';
	var passwd1 = '1';
	var passwd2 = '2';

	while (passwd1 != passwd2)
	{
		rl.question("Please insert account private key or leave it blank if you don't want to transact: ", function (_pkey) {
			pkey = _pkey;
		});
		while (pkey == '0') {await new Promise(resolve => setTimeout(resolve, 50));}

		if (pkey)
		{
			var passwd1 = ''
			rl.question('Type a password for protecting this account: ', function (_passwd1)
			{
				passwd1 = _passwd1;
			});
			while (passwd1 == '') {await new Promise(resolve => setTimeout(resolve, 50));}

			var passwd2 = ''
			rl.question('Retype the password: ', function (_passwd2)
			{
				passwd2 = _passwd2;
			});
			while (passwd2 == '') {await new Promise(resolve => setTimeout(resolve, 50));}

			if (passwd1 != passwd2)
			{
				console.log('Password didn\'t match  !!!');
			}
		}
		else
		{
			passwd1 = passwd2 = '';
		}

		rl.close();
	};

	rl.on('close', function () {
		if (passwd1 != passwd2)
		{
			console.log('Password didn\'t match  !!!');
			process.exit(0);
		}
	});

	account = new ot.Account(
		account_slot_id,
		mdi_url,
		mdi_user_address,
		address,
		pkey,
		passwd1
	)

	console.log("Creating new account:\n" + JSON.stringify(account, null, 4));

	if (pkey)
	{
		account_pk = ot.Account.getDecryptedPK(account, passwd1);

		if (account.address != account_pk.address)
		{
			console.log('Private key does not match account address!!!');
			process.exit(0);
		}
	}

	await ot.put(ot.Account, account);

	console.log('Account stored at slot: ' + account_slot_id + '.');

	process.exit(0)
}


var VERBOSE = false;

function set_verbose_option(value)
{
	VERBOSE = value;
}


module.exports = {
	cli_handle_account_list,
	cli_handle_account_create,
	cli_handle_account_delete,
	cli_handle_account_detail,
	cli_handle_mdi_create,
	cli_handle_mdi_credentials_list,
	cli_handle_mdi_remove,
	cli_handle_config_create,
	cli_handle_config_list,
	cli_handle_config_remove,
	set_verbose_option
}