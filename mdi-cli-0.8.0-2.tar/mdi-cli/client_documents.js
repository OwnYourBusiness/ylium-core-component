const readline = require('readline');

const ot = require('./libs/oybns_types.js');
const otx = require('./libs/oybns_transaction.js');
const oms = require('./libs/oybns_mdi_signer.js');
const od = require('./libs/oybns_document.js');

const cu = require('./client_utils.js');
const ct = require('./client_transactions.js');

const { ethers } = require("ethers");

async function cli_handle_document_comment(hash, comment_opts, opts)
{
	config = await cu.cli_get_config(opts);
	account = await cu.cli_get_account(opts);
	retval = await od.callDocumentComment(config, account, hash);
	console.log(JSON.stringify(retval, null, 4));
	process.exit(0);
}

async function cli_handle_document_history(document_hash, list_opts, options)
{
	account = await cu.cli_get_account(options);
	config = await cu.cli_get_config(options);

	document = await otx.getDocument(config, account, document_hash);

	if (! document.origin)
	{
		console.log("Error: document with hash: " + document_hash + " not found.");
		process.exit(1);
	}

	if (document_hash != document.origin)
	{
		console.log("Document with hash: " + document_hash + " is not the first document,");
		console.log("the original document hash is: " + document.origin + ",");
		console.log("the following history includes all documents in the chain.");

		document_hash = document.origin;
	}

	var documetOperationsList = await ot.search(ot.DocumentOperation, ['Documented', document.owner, document_hash]);

	for (let dop of documetOperationsList)
	{
		var transactionInfo = await otx.getTransactionInfo(config, account, dop.transaction_hash);

		if (! transactionInfo)
		{
			console.log("Transaction with hash " +  dop.transaction_hash + " not found")
		}
		else
		{
			ct.cli_log_transactionInfo(transactionInfo, account);			
		}
	}

	process.exit(0);
}

async function cli_handle_document_list(list_opts, options)
{
	account = await cu.cli_get_account(options);
	
	delegee = cu.cli_to_checksum_address(list_opts.delegee);
	
	//delegee can be null: in this case search is for all documents in cache
	var documentList = await ot.search(ot.DocumentList, [delegee]);

	console.log("%-24s %-66s %-34s".F('block timestamp', 'document hash', 'document owner'))
	console.log("%-24s %-66s %-34s".F('--', '--', '--'))

	for (let doc of documentList)
	{
		console.log("%-24s %-66s %-34s".F((new Date(doc.block_ts * 1000).toISOString()), doc.document_hash, doc.delegee))
		cu.cli_log_json("", doc);
	}

	process.exit(0);
}


async function cli_handle_document_operation(operation, document_hash, document_hash2, operation_opts, options)
{
	config = await cu.cli_get_config(options);
	account = await cu.cli_get_account(options);

	current_ts = Math.floor(Date.now()/1000);

	cu.cli_validate_operation("operation", operation);

	delegee = operation_opts.delegee;
	if (!delegee) delegee = account.address;
	cu.cli_validate_address("delegee", delegee);

	if (operation == 'supersede')
	{
		data = document_hash
		cu.cli_validate_document_hash("old document", data);
		document_hash = document_hash2
	}
	else if (operation == 'announce')
	{
		data = operation_opts.bin;
		if (! data) data = "0x0000000000000000000000000000000000000000000000000000000000000000"
		cu.cli_validate_document_hash("document bin label", data);
	}
	else if (operation == 'retract')
	{
		data = "0x0000000000000000000000000000000000000000000000000000000000000000"
	}	


	note = operation_opts.note;
	if (! note) note = "";
	if (note.length > 4096)
	{
		console.log("Note cannot be longer than 4096 bytes.");
		process.exit(1)	
	}

	if (! account.mdi_user_address)
	{
		console.log("Account does not have an mdi user address set.");
		process.exit(1)	
	}


	mdi_credentials = await cu.cli_get_mdi_credentials(config, account);

	if (VERBOSE) console.log("MDI Credentials: " + JSON.stringify(mdi_credentials, null, 4));

	account_mdi_user = mdi_credentials.mdi_user.split(':')[0];
	cu.cli_validate_address('mdi user', account_mdi_user);

	if (mdi_credentials.mdi_password.length <= 0)
	{
		console.log("Account does not have mdi password set.");
		process.exit(1)	
	}

	const rl = readline.createInterface({
	  input: process.stdin,
	  output: process.stdout
	});

	var password = 'some random text: 8998hjwrjke0'
		rl.question('Please insert account slot id: ' + account.id + " password: ", function (_res) {
		password = _res;
	});
	
	while (password == 'some random text: 8998hjwrjke0') {await new Promise(resolve => setTimeout(resolve, 1000));}
	if (password == '')
	{
		console.log("Password cannot be empty.");
		process.exit(1)	
	}

	var transaction = {
	  action: operation,
	  expirationTimestamp: current_ts+5*60,
	  maxFee: "" + ethers.utils.parseEther("10"),
	  delegee: delegee,
	  document: {
		hash: document_hash,
		data: data,
		note: note
	  }
	};

	if (VERBOSE) console.log("Transaction: " + JSON.stringify(transaction, null, 4));

	var signature;

	try {
		signature = await oms.signTransaction(config, account, password, transaction);
	}
	catch (err)
	{
		console.log(err.toString());
		process.exit(1)	
	}
	if (VERBOSE) console.log("Transaction signature: " + signature);

	var mdi_message = {
		'sequence': "" + current_ts,
		'mtx':  transaction,
	}

	mdi_message.mtx.signature = signature;
	mdi_message.mtx.signer = account.address;

	const mqtt = require('mqtt')

	if (VERBOSE) console.log("MDI message: " + JSON.stringify(mdi_message));

	var finished = 0;

	mqtt_options={
		username: mdi_credentials.mdi_user,
		password: mdi_credentials.mdi_password,
		clean:true
	};

	console.log("Connecting to MDI message broker: " + account.mdi_url);

	const client  = mqtt.connect(account.mdi_url, mqtt_options);

	client.on('connect', function () {
		console.log("... connected, subscribing for any reply ...");
		client.subscribe('mdi/v1/cl/' + account_mdi_user, function (err) {			
			if (!err) {
				console.log("... subscribed, sending message ...");
			 	client.publish('mdi/v1/op/' + account_mdi_user, JSON.stringify(mdi_message))
			}
		})
	})

	client.on('message', async function (topic, message) {

		response = JSON.parse(message.toString())

		console.log("... mdi server response: " + JSON.stringify(response));

		if (response.result == 'OK' && operation_opts.nowait == false)
		{
			var transaction_receipt;

			process.stdout.write("... waiting transaction to be mined ");

			while(! transaction_receipt)
			{
				await new Promise(resolve => setTimeout(resolve, 1000));
				transaction_receipt = await otx.getTransactionInfo(config, account, response.tx_hash);

				if (! transaction_receipt)
				{
					process.stdout.write(".");
				}
				else
				{
					console.log("\n... transaction with hash: " + response.tx_hash0 + " mined in block number: " + transaction_receipt.receipt.blockNumber);
					await otx.getDocumentEventsFromWeb3Provider(config, account, transaction_receipt.receipt.blockNumber,  transaction_receipt.receipt.blockNumber, delegee);
				}
			}

		}

	  client.end()
	  finished = 1
	})

	while (! finished) await new Promise(resolve => setTimeout(resolve, 100));

	process.exit(0)	
}

var VERBOSE = false;

function set_verbose_option(value)
{
	VERBOSE = value;
}

module.exports = {
	cli_handle_document_comment,
	cli_handle_document_operation,
	cli_handle_document_list,
	cli_handle_document_history,
	set_verbose_option
}