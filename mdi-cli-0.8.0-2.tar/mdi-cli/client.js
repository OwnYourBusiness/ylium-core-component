const { Command } = require('commander');
var Web3 = require('web3');

const ot = require('./libs/oybns_types.js');
const otx = require('./libs/oybns_transaction.js');
const oms = require('./libs/oybns_mdi_signer.js');

const cu = require('./client_utils.js');
const ca = require('./client_accounts.js');
const cd = require('./client_documents.js');
const ct = require('./client_transactions.js');

var VERBOSE = false;

const program = new Command();

program
	.name('node client.js')
	.description('CLI for YLIUM that implements MDI and direct ETH\nblockchain iterfaces for Document Nontarization System.')
	.option('-v, --verbose', 'turn on verbose mode', false)
	.version('0.0.1');

const __transaction = program.command('transaction')

	__transaction.option('-a, --account <slot_id>', 'use specific account slot id', '0')

	const __transaction_list = __transaction.command('list')
		.option('-d, --delegee <delegee address>', 'filter by delegee (owner) address')
		.option('-s, --signer <signer address>', 'filter by signer (delegated) address')
		.description('List cached transactions')
		.action((subcmd, options) => {
			cli_handle_global_options(program.opts());
			if (VERBOSE) console.log("Executing transaction list: options: " + JSON.stringify(__transaction_list.opts()) + " " + JSON.stringify(__transaction.opts()))
			if (__transaction_list.opts().delegee) cu.cli_validate_address("delegee", __transaction_list.opts().delegee);
			if (__transaction_list.opts().signer) cu.cli_validate_address("signer", __transaction_list.opts().signer);
			ct.cli_handle_transaction_list(__transaction_list.opts(), __transaction.opts());
		});
		
	__transaction.command('detail')
		.description('Show transaction detail')
		.argument('<tx hash>', 'transaction hash')
		.action(async (tx_hash) => {
			cli_handle_global_options(program.opts());
			if (VERBOSE) console.log("Executing transaction detail: <tx hash:" + tx_hash + "> options: " + JSON.stringify(__transaction.opts()))		
			cu.cli_validate_txhash("tx hash", tx_hash)
			ct.cli_handle_transaction_detail(tx_hash, __transaction.opts());
		});

	const __transaction_sync = __transaction.command('sync')
		.description('Download event logs and syncronize transaction history (for testnet start from block 27040386)')
		.option('-f, --from-block <from_block>', 'starting from block', '0')
		.option('-t, --to-block <to_block>', 'end search at block', 'latest')
		.option('-d, --delegee <delegee address>', 'use delegee address');

		__transaction_sync.action(() => {
			cli_handle_global_options(program.opts());
			if (VERBOSE) console.log("Executing download event logs: with options: " + JSON.stringify(__transaction_sync.opts()) + " " +  JSON.stringify(__transaction.opts()))
			if (__transaction_sync.opts().delegee) cu.cli_validate_address("delegee", __transaction_sync.opts().delegee);
			ct.cli_handle_transaction_sync(__transaction_sync.opts(), __transaction.opts());
		});

	__transaction.command('clear_cache')
		.description('Clear all transactions in cache')
		.action(async () => {
			cli_handle_global_options(program.opts());
			if (VERBOSE) console.log("Executing transaction clear cache: options: " + JSON.stringify(__transaction.opts()))	
			ct.cli_handle_transaction_clear_cache(__transaction.opts());
		});

	__transaction.command('hashes')
		.description('Retrurn known operations and events')
		.action(async () => {
			cli_handle_global_options(program.opts());
			if (VERBOSE) console.log("Executing transaction hashes print: options: " + JSON.stringify(__transaction.opts()))	
			ct.cli_handle_transaction_hashes();
		});

const __config = program.command('config')

	__config.command('show')
		.description('Show contracts address configuration')
		.action( () => {
			cli_handle_global_options(program.opts());
			if (VERBOSE) console.log("Executing config list")
			ca.cli_handle_config_list(__config.opts());
		});

	__config.command('initialize')
		.description('Initialize contracts address configuration')
		.argument('<web3 provider url>', 'web3 provider wss URL')
		.argument('[contract address]', 'contract address', '0x32848316dbb3D5DF85abD30d58f3Cc2B524E5e09')
		.argument('[token address]', 'token address', '0xA0c1f026e4f587829c15de0CA48aFA41Dc018aB6')
		.argument('[chain id]', 'chain id', '80001')
		.action( (web3_provider_url, contract_address, token_address, chain_id) => {
			cli_handle_global_options(program.opts());
			if (VERBOSE) console.log("Executing config initialize")
			ca.cli_handle_config_create(0, web3_provider_url, chain_id, contract_address, token_address, __config.opts());
		});

	__config.command('remove')
		.description('Remove contracts address configuration')
		.action( () => {
			cli_handle_global_options(program.opts());
			if (VERBOSE) console.log("Executing config remove")
			ca.cli_handle_config_remove(0, __config.opts());
		});

const __mdi_cred = program.command('credentials')

	__mdi_cred.command('list')
		.description('Show mdi credentials list')
		.action( () => {
			cli_handle_global_options(program.opts());
			if (VERBOSE) console.log("Executing mdi credential list")
			ca.cli_handle_mdi_credentials_list();
		});

	__mdi_cred.command('add')
		.description('Add mdi credentials')
		.argument('<mdi url>', 'mdi wss URL')
		.argument('<mdi user address>', 'mdi user address')
		.argument('<mdi password>', 'mdi password')
		.argument('<mdi password version>', 'mdi password version')
		.argument('[chain id]', 'chain id', '80001')
		.action( (mdi_url, mdi_user_address, mdi_password, mdi_password_version, chain_id) => {

			//cu.cli_validate_wss_url("web3 provider url", web3_provider_url);
			//cu.cli_validate_address("contract_address", contract_address);
			//cu.cli_validate_address("token_address", token_address);
			//cu.cli_validate_int("chain id", chain_id)
			//cu.cli_validate_int("mdi password version", chain_id)

			cli_handle_global_options(program.opts());
			if (VERBOSE) console.log("Executing mdi credential add")
			ca.cli_handle_mdi_create(mdi_url, chain_id, mdi_user_address, mdi_password, mdi_password_version, __mdi_cred.opts());
		});

	__mdi_cred.command('delete')
		.description('Delete mdi credentials')
		.argument('<mdi url>', 'mdi wss URL')
		.argument('<mdi user address>', 'mdi user address')
		.argument('[chain id]', 'chain id', '80001')
		.action( (mdi_url, mdi_user_address, chain_id) => {
			cli_handle_global_options(program.opts());
			if (VERBOSE) console.log("Executing mdi credential delete")
			ca.cli_handle_mdi_remove(mdi_url, chain_id, mdi_user_address, __mdi_cred.opts());
		});

const __account = program.command('account')

	__account.option('-a, --account <slot_id>', 'use specific account slot id', '0')

	__account.command('list')
		.description('Show account list')
		.action( () => {
			cli_handle_global_options(program.opts());
			if (VERBOSE) console.log("Executing account list")
			ca.cli_handle_account_list();
		});

	__account.command('detail')
		.description('Show account detail')
		.action( () => {
			cli_handle_global_options(program.opts());
			if (VERBOSE) console.log("Executing account detail: options: " + JSON.stringify(__account.opts()))
			ca.cli_handle_account_detail(__account.opts());
		});

	const __account_delete = __account.command('delete')
	__account_delete.option('-x', 'delete also mdi credentials', false)
	__account_delete.description('Delete an account')
	__account_delete.action( () => {
			cli_handle_global_options(program.opts());
			if (VERBOSE) console.log("Executing account delete: options: " + JSON.stringify(__account.opts()))
			ca.cli_handle_account_delete(__account.opts(), __account_delete.opts());		
		});

	__account.command('create')
		.description('Create a account')
		.argument('<mdi url>', 'mdi wss URL')
		.argument('<mdi user address>', 'mdi user address')
		.argument('<account address>', 'account address')

		.action((mdi_url, mdi_user, address) => {
			cli_handle_global_options(program.opts());
			cu.cli_validate_mdi_url("mdi url", mdi_url);
			cu.cli_validate_address("mdi user address", mdi_user);
			cu.cli_validate_address("account address", address);

			if (VERBOSE) console.log("Executing account create:"
																	+ "\n<mdi url:" + mdi_url + ">"
																	+ "\n<mdi user address:" + mdi_user + ">"																	
																	+ "\n<account address:" + address + ">"
																	+ "\n<options: " + JSON.stringify(__account.opts()) + ">")

			ca.cli_handle_account_create(mdi_url, mdi_user, address, __account.opts());
		});

const __document = program.command('document')

	__document.option('-a, --account <slot_id>', 'use specific account slot id', '0')

	__document_comment_command = __document.command('comment')
		.description('Show document detail')
		.argument('<hash>', 'document hash')
		.action((hash) => {
			cli_handle_global_options(program.opts());
			cd.cli_handle_document_comment(hash, __document_comment_command.opts(), __document.opts());
		});

	__document_list_command = __document.command('list')
		.description('Show documet list')
		.option('-d, --delegee <delegee address>', 'use delegee address')
		.action(() => {
			cli_handle_global_options(program.opts());
			if (VERBOSE) console.log("Executing document list: with options: " + JSON.stringify(__document_list_command.opts()) + " - " + JSON.stringify(__document.opts()))
			if (__document_list_command.opts().delegee) cu.cli_validate_address("delegee", __document_list_command.opts().delegee);
			cd.cli_handle_document_list(__document_list_command.opts(), __document.opts());
		});	

	__document_history_command = __document.command('history')
		.description('Show documet history')
		.argument('<hash>', 'document hash')
		.action((hash) => {
			cli_handle_global_options(program.opts());
			if (VERBOSE) console.log("Executing document history: <document hash:" + hash + " with options: " + JSON.stringify(__document_history_command.opts()) + " - " + JSON.stringify(__document.opts()))
			cu.cli_validate_document_hash("document hash", hash);
			cd.cli_handle_document_history(hash, __document_history_command.opts(), __document.opts());
		});

	__document_announce_command = __document.command('announce')
		.description('Announce a new document')
		.option('-d, --delegee <delegee address>', 'use delegee address')
		.option('-b, --bin <binary label>', 'specify a 32 bytes label to attach to document')
		.option('-n, --note <text note>', 'specify a text note to attach to document')
		.option('--nowait', 'skip wait for the transaction recepit', false)
		.argument('<document hash>', 'document hash')
		.action((hash) => {
			cli_handle_global_options(program.opts());
			if (VERBOSE) console.log("Executing document announce: <document hash:" + hash + " with options: " + JSON.stringify(__document_announce_command.opts()) + " - " + JSON.stringify(__document.opts()))
			cu.cli_validate_document_hash("document hash", hash);
			if (__document_announce_command.opts().delegee) cu.cli_validate_address("delegee", __document_announce_command.opts().delegee);	
			cd.cli_handle_document_operation('announce', hash, '', __document_announce_command.opts(), __document.opts());
		});

	__document_supersede_command = __document.command('supersede')
		.description('Supersede a document')
		.option('-d, --delegee <delegee address>', 'use delegee address')
		.option('-n, --note <text note>', 'specify a text note to attach to the operation')
		.argument('<old document hash>', 'old document hash')
		.argument('<new document hash>', 'new document hash')
		.option('--nowait', 'skip wait for the transaction recepit', false)
		.action((old_hash, new_hash) => {
			cli_handle_global_options(program.opts());
			if (VERBOSE) console.log("Executing document announce: <old document hash:" + old_hash + ">  <new document hash:" + new_hash + "> with options: " + JSON.stringify(__document_supersede_command.opts()) + " - " + JSON.stringify(__document.opts()))
			cu.cli_validate_document_hash("old document hash", old_hash);
			cu.cli_validate_document_hash("new document hash", new_hash);
			if (__document_supersede_command.opts().delegee) cu.cli_validate_address("delegee", __document_supersede_command.opts().delegee);			
			cd.cli_handle_document_operation('supersede', new_hash, old_hash, __document_supersede_command.opts(), __document.opts());
		});

	__document_retract_command = __document.command('retract')
		.description('Retract a document')
		.option('-d, --delegee <delegee address>', 'use delegee address')
		.option('-n, --note <text note>', 'specify a text note to attach to the operation')
		.argument('<document hash>', 'document hash')
		.option('--nowait', 'skip wait for the transaction recepit', false)
		.action((hash) => {
			cli_handle_global_options(program.opts());
			if (VERBOSE) console.log("Executing document retract: <document hash:" + hash + "> with options: " + JSON.stringify(__document_retract_command.opts()) + " - " + JSON.stringify(__document.opts()))
			cu.cli_validate_document_hash("document hash", hash);
			if (__document_retract_command.opts().delegee) cu.cli_validate_address("delegee", __document_retract_command.opts().delegee);				
			cd.cli_handle_document_operation('retract', hash, '', __document_retract_command.opts(), __document.opts());
		});		

program.parse();

function cli_handle_global_options(options)
{
	if (options.verbose)
	{
		VERBOSE = true;
		cu.set_verbose_option(VERBOSE);
		ct.set_verbose_option(VERBOSE);
		ca.set_verbose_option(VERBOSE);
		cd.set_verbose_option(VERBOSE);
		ot.set_verbose_option(VERBOSE);		
		otx.set_verbose_option(VERBOSE);
		oms.set_verbose_option(VERBOSE);
	}
}
