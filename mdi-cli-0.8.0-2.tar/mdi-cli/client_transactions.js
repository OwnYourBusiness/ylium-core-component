const cu = require('./client_utils.js');

const otx = require('./libs/oybns_transaction.js');
const oms = require('./libs/oybns_mdi_signer.js');

function cli_handle_transaction_hashes()
{
	console.log(otx.get_known_operations_and_events());
}

async function cli_handle_transaction_detail(tx_hash, options)
{
	account = await cu.cli_get_account(options);
	config = await cu.cli_get_config(options);

	transactionInfo = await otx.getTransactionInfo(config, account, tx_hash);

	if (! transactionInfo)
	{
		console.log("Transaction with hash " +  tx_hash + " not found")
		process.exit(2)
	}

	cli_log_transactionInfo(transactionInfo, account);

	process.exit(0)
}

async function cli_handle_transaction_list(list_opts, options)
{
	account = await cu.cli_get_account(options);

	delegee = cu.cli_to_checksum_address(list_opts.delegee);
	delegated = cu.cli_to_checksum_address(list_opts.signer);

	transactionInfoList = await otx.getTransactionList(account, delegee, delegated);

	console.log('%-66s %-9s %-66s %-66s'.F('tx hash', 'operation', 'document hash', 'new document hash'))
	console.log('%-66s %-9s %-66s %-66s'.F('--', '--', '--', '--'))

	transactionInfoList.map(transactionInfo => {
		cli_log_transactionInfo_short(transactionInfo, account);
	});

	console.log('%-66s %-9s %-66s'.F('--', '--', '--'))

	process.exit(0)
}

async function cli_handle_transaction_sync(sync_options, options)
{
	account = await cu.cli_get_account(options);
	config = await cu.cli_get_config(options);


	fromBlock = sync_options.fromBlock;
	toBlock = sync_options.toBlock;

	delegee = sync_options.delegee;
	if (! delegee) delegee = account.address;

	await otx.getDocumentEventsFromWeb3Provider(config, account, fromBlock, toBlock, delegee);

	process.exit(0)
}

async function cli_handle_transaction_clear_cache(opetions)
{
	await otx.clearCache();
	console.log("Cache cleared.");
	process.exit(0)
}

function cli_log_transactionInfo(transactionInfo, account)
{
	transactionReceipt = transactionInfo.receipt;
	result_log_parsed = otx.parseTransactionLogs(transactionReceipt.logs, account)

	state_desc = "OK"
	if (! transactionReceipt.status) state_desc = "KO"

	var __PAD = 20;	//padding for output formatting

	console.log("---");
	console.log("%-20s %-66s %s".F("Tx hash", transactionReceipt.transactionHash, ""));
	console.log("%-20s %-66s %s".F("Tx timestamp", transactionInfo.block_ts, "(" + new Date(transactionInfo.block_ts * 1000).toISOString() + ")"));
	console.log("%-20s %-66s %s".F("From", transactionReceipt.from, ""));
	console.log("%-20s %-66s %s".F("Status", state_desc, ""));

	result_log_parsed.events.map(lep => {

		if (lep.event == "Transfer")
		{
			//console.log("Price: " + lep.amount + " tokens");
		}

		if (lep.event == "Documented")
		{
			if (lep.operation_desc == 'announce')
			{

				if (lep.document_hash == lep.document_data)
				{
					console.log("%-20s %-66s %s".F("Operation", "announce", ""));
					console.log("%-20s %-66s %s".F("Document hash", lep.document_hash, ""));
				}
				else
				{
					console.log("%-20s %-66s %s".F("Operation", "supersede", ""));
					console.log("%-20s %-66s %s".F("Document hash", lep.document_data, "(old document)"));
					console.log("%20s %-66s %s".F("", lep.document_hash, "(new document)"));
				}
			}
			else if (lep.operation_desc == 'supersede')
			{
				// just consider events relative to the document of this transaction
				// these events always refers to previus document or first document
			}
			else if (lep.operation_desc == 'retract')
			{
				console.log("%-20s %-66s %s".F("Operation", "retract", ""));
				console.log("%-20s %-66s %s".F("Document hash", lep.document_hash, ""));
				console.log("%-20s %-66s %s".F("", lep.document_data, "(original document)"));
			}			
		}

		if (lep.event == "Transacted")
		{
			console.log("%-20s %-66s %s".F("Document owner", lep.delegee, "(delegee)"));
		}

		if (lep.event == "TransactedDelegated")
		{
			console.log("%-20s %-66s %s".F("Tx signer", lep.delegated, "(delegated)"));
		}

		if (lep.event == "Labeled")
		{
			console.log("%-20s %-66s %s".F("Document label", lep.document_label, ""));
		}

		if (lep.event == "Annoted")
		{
			console.log("%-20s %-66s %s".F("Document note", lep.note, ""));
		}
	})

	console.log("%-20s %-66s %s".F("Block hash", transactionReceipt.blockHash, ""));
	console.log("%-20s %-66s %s".F("Block number", transactionReceipt.blockNumber, ""));
	console.log("%-20s %-66s %s".F("Cumulative gas used", transactionReceipt.cumulativeGasUsed, ""));


	console.log("");
}

function cli_log_transactionInfo_short(transactionInfo, account)
{
	transactionReceipt = transactionInfo.receipt;

	result_log_parsed = otx.parseTransactionLogs(transactionReceipt.logs, account)

	result_log_parsed.events.map(lep => {

		dochash = "";
		dochash2 = "";
		operation = "";

		if (lep.event == "Documented")
		{
			if (lep.operation_desc == 'announce')
			{ 
				if (lep.document_hash == lep.document_data)
				{
					dochash = lep.document_hash;
					operation = 'announce';
				}
				else
				{
					dochash = lep.document_data;
					dochash2 = lep.document_hash;					
					operation = 'supersede';
				}
			}
			else if (lep.operation_desc == 'supersede')
			{
				// just consider events relative to the document of this transaction
				// these events always refers to previus document or first document
			}
			else if (lep.operation_desc == 'retract')
			{
				dochash = lep.document_hash;
				operation = 'retract';
			}
		}

		if (operation != "") console.log('%-66s %-9s %-66s %-66s'.F(transactionReceipt.transactionHash, operation, dochash, dochash2));
	})

}

var VERBOSE = false;

function set_verbose_option(value)
{
	VERBOSE = value;
}

module.exports = {
	cli_log_transactionInfo_short,
	cli_log_transactionInfo,
	cli_handle_transaction_clear_cache,
	cli_handle_transaction_sync,
	cli_handle_transaction_list,
	cli_handle_transaction_detail,
	cli_handle_transaction_hashes,	
	set_verbose_option
}
