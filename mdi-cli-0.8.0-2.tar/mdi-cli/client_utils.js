var Web3 = require('web3');

const ot = require('./libs/oybns_types.js');

async function cli_get_account(options)
{
	account_slot_id = parseInt(options.account)

	account = await ot.get(ot.Account, [account_slot_id]);

	if (! account)
	{
		console.log("account in slot id: " + account_slot_id + " not found")
		process.exit(1)
	}

	return account;
}

async function cli_get_config(options)
{
	config = await ot.get(ot.Config, [0]);

	if (! config)
	{
		console.log("config with id: " + 0 +" not found (please activate the smart contract configuration).")
		process.exit(1)
	}

	console.log("Using configuration: " + JSON.stringify(config, null, 4))

	return config
}

async function cli_get_mdi_credentials(config, account)
{
	credential = await ot.get(ot.MdiCredentials, [account.mdi_url, config.chain_id, account.mdi_user_address]);

	if (! credential)
	{
		console.log("credential for : " + account.mdi_url + ", " + config.chain_id + ", " + account.address + " not found")
		process.exit(1)
	}

	return credential
}

function cli_validate_int(label, value)
{
	if (! /^\d+$/.test(value))
	{
		console.log("Error: invalid parameter: " + label + ": value is not a number.")
		process.exit(2)
	}
}

function cli_validate_mdi_url(label, url)
{
	if (! /^wss:\/\/[^ "]+$/.test(url))
	{
		console.log("Error: invalid parameter: " + label + ". MDI websocket URL <" + url + ">must start with wss://.")
		process.exit(2)
	}
}

function cli_validate_wss_url(label, url)
{
	if (! /^wss:\/\/[^ "]+$/.test(url))
	{
		console.log("Error: invalid parameter: " + label + ". Websocket provider URL must start with wss://.")
		process.exit(2)
	}
}

function cli_validate_address(label, address)
{
	if (! Web3.utils.isAddress(address))
	{
		console.log("Error: invalid " + label + " address: " + address + " (use checksum address format).")
		process.exit(2)
	}
}

function cli_to_checksum_address(address)
{
	return Web3.utils.toChecksumAddress(address);
}

function cli_validate_not_empty(label, value)
{
	if (! value)
	{
		console.log("Error: invalid parameter " + label + ": parameter cannot be empty.")
		process.exit(2)
	}
}

function cli_validate_operation(label, value)
{
	if (value != 'announce' && value != 'supersede' && value != 'retract')
	{
		console.log("Error: invalid parameter " + label + ": parameter must be any of announce, supersede or retract operation.")
		process.exit(2)
	}
}

function cli_validate_document_hash(label, tx_hash)
{
	cli_validate_txhash(label, tx_hash)
}

function cli_validate_txhash(label, tx_hash)
{
	if (! /^0x([A-Fa-f0-9]{64})$/.test(tx_hash))
	{
		console.log("Error: invalid parameter: " + label);
		process.exit(2)
	}
}

function cli_log_json(label, obj)
{
	if (VERBOSE) console.log(label, JSON.stringify(obj, null, 4));
}

String.form = function(str, arr) {
    var i = -1;
    function callback(exp, p0, p1, p2, p3, p4) {
        if (exp=='%%') return '%';
        if (arr[++i]===undefined) return undefined;
        exp  = p2 ? parseInt(p2.substr(1)) : undefined;
        var base = p3 ? parseInt(p3.substr(1)) : undefined;
        var val;
        switch (p4) {
            case 's': val = arr[i]; break;
            case 'c': val = arr[i][0]; break;
            case 'f': val = parseFloat(arr[i]).toFixed(exp); break;
            case 'p': val = parseFloat(arr[i]).toPrecision(exp); break;
            case 'e': val = parseFloat(arr[i]).toExponential(exp); break;
            case 'x': val = parseInt(arr[i]).toString(base?base:16); break;
            case 'd': val = parseFloat(parseInt(arr[i], base?base:10).toPrecision(exp)).toFixed(0); break;
        }
        val = typeof(val)=='object' ? JSON.stringify(val) : val.toString(base);
        var sz = parseInt(p1); /* padding size */
        var ch = p1 && p1[0]=='0' ? '0' : ' '; /* isnull? */
        while (val.length<sz) val = p0 !== undefined ? val+ch : ch+val; /* isminus? */
       return val;
    }
    var regex = /%(-)?(0?[0-9]+)?([.][0-9]+)?([#][0-9]+)?([scfpexd%])/g;
    return str.replace(regex, callback);
}

String.prototype.F = function() {
    return String.form(this, Array.prototype.slice.call(arguments));
}

var VERBOSE = false;

function set_verbose_option(value)
{
	VERBOSE = value;
}

module.exports = {
	cli_get_account,
	cli_get_mdi_credentials,
	cli_get_config,
	cli_validate_txhash,
	cli_validate_document_hash,
	cli_validate_operation,
	cli_validate_not_empty,
	cli_validate_address,
	cli_validate_wss_url,
	cli_validate_mdi_url,
	cli_log_json,
	set_verbose_option,
	cli_to_checksum_address,
	cli_validate_int	
}